from setuptools import setup


setup(
    name="tiniest_latex_lib",
    version="0.1",
    packages=['tiniest_latex_lib'],
    author="who",
    description="hw2"
)

# pip install dist/tiniest_latex_lib-0.1-py3-none-any.whl
